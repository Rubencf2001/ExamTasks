/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator;



/**
 *
 * @author ruben
 */
public class Program {
 /**
     * Evaluate statement represented as string.
     *
     * @param args
     * @param statement mathematical statement containing digits, '.' (dot) as decimal mark,
     *                  parentheses, operations signs '+', '-', '*', '/'<br>
     *                  Example: <code>(1 + 38) * 4.5 - 1 / 2.</code>
     * @return string value containing result of evaluation or null if statement is invalid
     */
    
   
    public static void main(String[] args) {
  
    Calculator c = new Calculator();
    
        System.out.println(c.evaluate("(1+38)*4-5"));
        System.out.println(c.evaluate("7*6/2+8"));
        System.out.println(c.evaluate("8.//2-1"));
        
    }
}
    