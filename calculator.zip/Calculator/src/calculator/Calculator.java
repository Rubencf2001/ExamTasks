/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator;

import static java.lang.Double.parseDouble;
import java.util.ArrayList;

/**
 *
 * @author ruben
 */
public class Calculator {

    /*  This class emulates a calculator. It works introducing a String and the program reads it and save all the numbers in an ArrayList
    I have created two ArrayList to save two different types of numbers, those which are between parenthesis and those which not
    Then I have the variable 'sign' and 'signParen' where I saved, as the name says, 
    the sign to evaluate the operation that is out of the parenthesis and to evaluate that one which is not.
     */
    ArrayList<Double> numbers = new ArrayList<>();
    ArrayList<Double> numbersParenth = new ArrayList<>();
    protected char sign;
    protected char signParen;

    /*This is the Constructor method to initialize the class*/
    public Calculator() {
        
    }
    //Getters & Setters
        public void setSign(char Sign) {
        this.sign = Sign;
    }

    public char getSign() {
        return sign;
    }

    public ArrayList<Double> getNumbers() {
        return numbers;
    }

    public ArrayList<Double> getNumbersParenth() {
        return numbersParenth;
    }

    public char getSignParen() {
        return signParen;
    }

    public void setNumbers(ArrayList<Double> numbers) {
        this.numbers = numbers;
    }

    public void setNumbersParenth(ArrayList<Double> numbersParenth) {
        this.numbersParenth = numbersParenth;
    }

    public void setSignParen(char signParen) {
        this.signParen = signParen;
    }
    //end Getters & Setters

    //  This static method is used to round the final result to only get 4 significant digits
    public static double round(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

    /*  Here I have the method that evaluates if the operation introduced is correct or not
    I have some variables to check if there is not a letter included, if there is '(' to check if there is ')' too,
    those are the 'open' and 'close' variables.
    
     */
    public static boolean validate(String operation) {
        boolean valid = true; //valid is for checking that the operation does not have any letter.
        boolean open = false; //open check if a parenthesis starts
        boolean close = false;//open check if a parenthesis closes
        boolean finalValid = false;//final valid is true if the conditions belows are met
        for (int i = 0; i < operation.length(); i++) {
            if (Character.isLetter(operation.charAt(i))) {
                valid = false;
            }/* This 'if' checks if the operation does not have any syntax error, for instance, '//' or '8..2' */
            if (operation.charAt(i) == '.' || operation.charAt(i) == '+' || operation.charAt(i) == '-' || operation.charAt(i) == '*' || operation.charAt(i) == '/') {
                char value = operation.charAt(i);
                i++;
                if (value == operation.charAt(i)) {
                    valid = false;
                    i--;
                } else {
                    i--;
                }
            }
            //these 'if' check that if a parenthesis has a start it also has an end
            if (operation.charAt(i) == '(') {
                open = true;
            }
            if (operation.charAt(i) == ')') {
                close = true;
            }

        }
        //Here I have to choices one that has parenthesis and both, open and close, are true and the oposite that both, open and close, are false
        if ((open && close && valid) || (!open && !close && valid)) {
            finalValid = true;
        }
        return finalValid;
    }

    /*  As I could have two types of operations, on between parenthesis and outside*/
 /*  This method is for the operation between parenthesis. For the reason that I have two ArrayList, I also need two methods to operate those numbers that
        the ArrayList contains
     */
    //This one operates numbers between parenthesis
    public double operateParenth() {
        double result = 0;
        switch (signParen) {
            case '+' -> {
                result = numbersParenth.get(0) + numbersParenth.get(1);
            }
            case '*' -> {
                result = numbersParenth.get(0) * numbersParenth.get(1);
            }
            case '/' -> {
                result = numbersParenth.get(0) / numbersParenth.get(1);
            }
            case '-' -> {
                result = numbersParenth.get(0) - numbersParenth.get(1);
            }

        }
        return result;
    }
//This one operates numbers outside parenthesis

    public double operate() {
        double result = 0;
        switch (sign) {
            case '+' -> {
                result = numbers.get(0) + numbers.get(1);
            }
            case '*' -> {
                result = numbers.get(0) * numbers.get(1);
            }
            case '/' -> {
                result = numbers.get(0) / numbers.get(1);
            }
            case '-' -> {
                result = numbers.get(0) - numbers.get(1);
            }
        }
        return result;
    }

    /*
     This method read the String between parenthesis and saves its numbers in an ArrayList 'numbersParen' to operate
    and then introduce them in the ArrayList 'numbers'
     */
    public double readParen(String operation) {
        /*This is an easy method, it just read the characters of the string and evaluate each one. If it's a number do this, otherwise do this.*/
        double result = 0;
        String aux = "";
        double number;
        int i = 0;
        while (i < operation.length()) {

            if (operation.charAt(i) != '+' && operation.charAt(i) != '-' && operation.charAt(i) != '*' && operation.charAt(i) != '/') {
                aux += operation.charAt(i);
                i++;
            } else if (operation.charAt(i) == '-') {
                /*to save negative numbers I evaluated '-' sign separately 
                because a subtraction is just a sum between two numbers whose one number is negative.
                 */
                aux += operation.charAt(i);
                i++;

            } else if (operation.charAt(i) == '+' || operation.charAt(i) == '*' || operation.charAt(i) == '/') {
                signParen = operation.charAt(i);//Here I save the sign inside the parenthesis to operate later

                number = parseDouble(aux);
                numbersParenth.add(number);
                aux = "";
                i++;
            }
        }
        number = parseDouble(aux);
        numbersParenth.add(number);
        return result;
    }

    /*Here it is the main method of the class it is just like the method above but the difference is that here it evaluates if there are '(' ')', 
    the rest of the functionalities are the same*/
    public double read(String operation) {
        double result = 0;//variable where I save the final result 
        String subStr = "";//String where I save the string between parenthesis
        boolean check = false;/*This boolean has an important function it checks if there are parenthesis or not*/
        double parenResult;//Here I save the result of the operation between parenthesis
        String aux = "";//String that collects numbers until a sign or ')' is found
        double number;//variable where I save the conversion from String to double
        int i = 0;//just a counter.
        while (i < operation.length()) {
            //if charAt(i) is a number it saves it in aux
            if (operation.charAt(i) != '+' && operation.charAt(i) != '-' && operation.charAt(i) != '*' && operation.charAt(i) != '/' && operation.charAt(i) != '(' && operation.charAt(i) != ')') {
                aux += operation.charAt(i);

                i++;
                //if its a open parenthesis saves in 'subStr' until it finds a close parenthesis
            } else if (operation.charAt(i) == '(') {
                check = true;
                while (operation.charAt(i) != ')') {
                    i++;
                    subStr += operation.charAt(i);

                }
                //I remove last character of the subStr to make it work or else it subStr would be like this "x+y)"
                subStr = subStr.substring(0, subStr.length() - 1);
                //Then I call the method 'readParen' and 'operateParenth' and save the result in 'numbers'
                readParen(subStr);
                parenResult = operateParenth();

                numbers.add(parenResult);
                if (numbers.size() == 2) {
                    number = operate();
                    numbers.clear();
                    numbers.add(number);

                }
                /*to save negative numbers I evaluated '-' sign separately 
                because a subtraction is just a sum between two numbers whose one number is negative.
                 */
                if (operation.charAt(i) == '-') {

                    aux += operation.charAt(i);
                    i++;

                } else if (operation.charAt(i) != '+' && operation.charAt(i) != '-' && operation.charAt(i) != '*' && operation.charAt(i) != '/' && operation.charAt(i) != '(' && operation.charAt(i) != ')') {
                    i++;
                    aux += operation.charAt(i);
                } else if (operation.charAt(i) == ')') {

                    i++;
                }
                //Here I evaluate the condition of starting the operation with a negative number
            } else if (operation.charAt(i) == '-' && !"".equals(aux)) {

                number = parseDouble(aux);
                numbers.add(number);
                /*Because the operate method only operates 2 numbers if I have two numbers then I operate them and add the result, 
                after that I remove the other two numbers*/
                if (numbers.size() >= 2) {
                    numbers.add(operate());
                    numbers.remove(0);
                    numbers.remove(0);
                }
                aux = "";
                //As I introduced a negative number I can change the sign of the operation to '+'
            } else if (operation.charAt(i) == '-') {
                sign = '+';
                aux += operation.charAt(i);
                i++;
                /*  If the character read is a sign I check
                 */
            } else if ((operation.charAt(i) == '+' || operation.charAt(i) == '*' || operation.charAt(i) == '/')) {
                //this is the case that there are not parenthesis
                if ((numbers.isEmpty() || !check)) {

                    number = parseDouble(aux);
                    numbers.add(number);
                    aux = "";
                    if (numbers.size() == 2) {
                        numbers.add(operate());
                        numbers.remove(0);
                        numbers.remove(0);

                    }
                    sign = operation.charAt(i);
                    i++;
                    //the other case if there are parenthesis
                } else {
                    sign = operation.charAt(i);
                    i++;
                }

            }
        }
        //After all I introduce the last number
        number = parseDouble(aux);
        numbers.add(number);

        return result;
    }
    //Now this method is simple. Just calling the other methods.
    public String evaluate(String operation) {
        double result;
        //in case the operation introduced is a correct format
        if (validate(operation)) {
            read(operation);
            result = operate();
            result = round(result, 4);
            numbers.clear();
            numbersParenth.clear();
            return ""+result;
        } else {
            //the other case
            return "null";
        }
    }
}
