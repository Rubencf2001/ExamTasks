/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package subsequence;

import java.util.ArrayList;
import java.util.List;

import java.util.stream.Stream;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author ruben
 */
public class Subsequence {

    /**
     * @param args the command line arguments
     */
    ArrayList<Object> sequence = new ArrayList<>();

    Subsequence() {

    }

    public boolean find(List a, List b) {
        boolean result = false;
        if (a.size() <= b.size()) {
            for (int i = 0; i < a.size(); i++) {
                for (int j = 0; j < b.size(); j++) {

                    if (a.get(i) == b.get(j)) {

                        if ((sequence.isEmpty() || !sequence.contains(b.get(j) )) || (b.get(j) == sequence.get(i))){
                            sequence.add(a.get(i));
                        }

                        result = true;

                    } else if (a.get(i) != b.get(j)) {
                        result = false;
                    }
                }
            }
        } else {
            result = false;
        }
        System.out.println(sequence);
        System.out.println(sequence.size());
        return result;
    }

}
