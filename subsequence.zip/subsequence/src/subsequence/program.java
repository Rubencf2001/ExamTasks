/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package subsequence;

import java.util.List;
import static java.util.stream.Collectors.toList;
import java.util.stream.Stream;

/**
 *
 * @author ruben
 */
public class program {
       public static void main(String[] args) {
        List a = Stream.of(1, 2, 3, 4, 5).collect(toList());
        List b = Stream.of(1, 2, 3, 4, 6, 1, 2, 3, 20).collect(toList());
        boolean result;
        Subsequence subsequence = new Subsequence();
        
           System.out.println(result=subsequence.find(a, b));
}
}
