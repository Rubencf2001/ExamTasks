package currency;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import static java.lang.Double.parseDouble;
import java.util.ArrayList;

/**
 *
 * @author ruben
 */
public class program {

    /**
     * Currency converter which converts the input statement and returns the
     * result value.
     *
     * @param dollarToEuroRate 1 Dollar equals XX Euro
     * @param statement input statement to convert
     * @return converted value
     */
    
        /**
         *I know I did not get all the exercise, I got the validation and I made it work in simple conversions
     * @param args
         */

    public static void main(String[] args) {
        CurrencyConverter c= new CurrencyConverter();
      
        //System.out.println(c.convert(0.8,"convertToDollar(20euro)"));
        System.out.println(c.convert(0.8,"convertToEuro($20)"));
        System.out.println(c.convert(0.8,"convertToDollar(20euro)"));
        
    
        // TODO code application logic here
    }

}
