/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package currency;

import static java.lang.Double.parseDouble;

/**
 *
 * @author ruben
 */
public class CurrencyConverter {

    protected double count = 0;
    protected char sign;
    String a = "convertToDollar";
    String b = "convertToE";

    CurrencyConverter() {

    }

    public static String invert(String str) {
        String inverted = "";
        String number = "";
        for (int i =0 ;i<=str.length() - 1; i++) {
            Boolean flag = Character.isDigit(str.charAt(i));
            inverted += str.charAt(i);

            if (flag) {
                number += str.charAt(i);

            }
            

        }

        return number;
    }

    public String convert(double DollarToEuroRate, String statement) {
        String subStr;
        subStr = invert(statement);
        boolean dollar = false;
        boolean correct=false;
        String aux = "";
        double converted;
        double result;

        for (int i = 1; i < statement.length(); i++) {
              if(statement.contains("Dollar")){
                  correct = !statement.contains("($");
              }
              if(statement.contains("Euro")){
                  correct=statement.contains("$");
                  dollar=true;
              }
           
            if (correct && !dollar) {

                converted = parseDouble(subStr);
                result = converted / DollarToEuroRate;
                count = result;
                return count + "euro";
              
            } else if (dollar && correct) {
                
                result = parseDouble(subStr);
                result *= DollarToEuroRate;
                count = result;
                
            }
            if(statement.contains("+")||statement.contains("-")){
                i++; 
                Boolean flag = Character.isDigit(statement.charAt(i));
                while(flag){
                    
                    aux+=statement.charAt(i);
                    
                }
                System.out.println(aux);
            }
           
        
            
        }if(!correct){
            return null;
        }
        return "$" + count;
        
    }
        


    public void setCount(double count) {
        this.count = count;
    }

    public void setSign(char sign) {
        this.sign = sign;
    }

    public double getCount() {
        return count;
    }

    public char getSign() {
        return sign;
    }

}
